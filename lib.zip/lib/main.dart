import 'package:collection_app/basics.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(const MaterialApp(home: Basics(),),);
}